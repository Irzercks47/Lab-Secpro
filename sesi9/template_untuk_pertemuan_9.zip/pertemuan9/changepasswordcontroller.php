<?php
include "connect.php";

$new_password = $_POST["new-password"];
$sql = "update users set password='$new_password'";
$con->query($sql);

header("Location: changepassword.php");