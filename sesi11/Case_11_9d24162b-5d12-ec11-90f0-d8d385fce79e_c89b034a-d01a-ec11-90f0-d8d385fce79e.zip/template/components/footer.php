<script src="<?= asset('vendor/jquery/jquery-3.3.1.min.js'); ?>"></script>
<script src="<?= asset('vendor/bootstrap/js/bootstrap.min.js'); ?>"></script>