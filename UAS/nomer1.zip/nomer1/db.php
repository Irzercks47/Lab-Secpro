<?php
$conn = new mysqli('localhost', 'root', '', 'pph');
