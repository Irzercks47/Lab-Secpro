import React, {Component} from 'react'
import {Navbar,Nav} from 'react-bootstrap'
import { BrowserRouter as Router, Switch,Route,Link} from 'react-router-dom'
import Home from "./Home"
import About from "./About"
import Product from "./Product"
import Contact from "./Contact"

export default class NavbarComp extends Component {
    render(){
        return(
            <Router>
            <div>
                <Navbar bg="light" expand="lg">
                    <Navbar.Brand href="#home">Michael Kwan_2301877565</Navbar.Brand>
                    <Navbar.Toggle aria-controls="basic-navbar-nav" />
                    <Navbar.Collapse id="basic-navbar-nav">
                        <Nav className="me-auto">
                            <Nav.Link as={Link} to={"/home"} >Home</Nav.Link>
                            <Nav.Link as={Link} to={"/about"} >About</Nav.Link>                                
                            <Nav.Link as={Link} to={"/product"} >Product</Nav.Link>
                            <Nav.Link as={Link} to={"/contact"} >Contact</Nav.Link>    
                        </Nav>
                    </Navbar.Collapse>
                </Navbar>
            </div>
            <div>
                <Switch>
                    <Route path='/about'>
                        <About />
                    </Route>
                    <Route path='/product'>
                        <Product />
                    </Route>
                    <Route path='/contact'>
                        <Contact />
                    </Route>
                    <Route path='/home'>
                        <Home />
                    </Route>
                </Switch>
            </div>
            </Router>
        )
    }
}