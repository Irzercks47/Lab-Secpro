import React, {Component} from 'react'
import contact from '../assets/contact-us.png'

export default class Contact extends Component {
    render(){
        return(
            <div>
                <h1>Contact</h1>
                <img src={contact} alt="" width="980px" height="200px" />
            </div>
        )
    }
}