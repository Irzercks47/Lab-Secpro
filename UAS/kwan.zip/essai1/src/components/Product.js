import React, {Component} from 'react'
import product from '../assets/tipe-produk.png'

export default class Product extends Component {
    render(){
        return(
            <div>
                <h1>Product</h1>
                <img src={product} alt="" width="980px" height="200px" />
            </div>
        )
    }
}