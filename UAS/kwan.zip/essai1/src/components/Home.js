import React, {Component} from 'react'
import home from '../assets/home.jpg'

export default class Home extends Component {
    render(){
        return(
            <div>
                <h1>Home</h1>
                <img src={home} alt="" width="980px" height="200px" />
            </div>
        )
    }
}